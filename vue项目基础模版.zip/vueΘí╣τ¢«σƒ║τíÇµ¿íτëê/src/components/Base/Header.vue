<template>
  <header>顶部栏</header>
</template>

<script>
export default {
  name: 'BaseHeader',
};
</script>

<style lang="less" scoped>
header {
  height: 44px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #e8e8e8;
}
</style>
