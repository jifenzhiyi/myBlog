import enUS from 'ant-design-vue/es/locale-provider/en_US';

export default {
  antLocale: enUS,
  lang: 'English',
};
