import zhCN from 'ant-design-vue/es/locale-provider/zh_CN';

export default {
  antLocale: zhCN,
  lang: '中文',
};
